<script lang="ts">

    import { onMount } from 'svelte';
    import TrashIcon from '@phosphor-icons/core/regular/trash.svg?component';
    import ReinstallIcon from '@phosphor-icons/core/regular/arrow-clockwise.svg?component';
    import FolderIcon from '@phosphor-icons/core/regular/folder-open.svg?component';
    import CacheClearIcon from '@phosphor-icons/core/regular/arrows-clockwise.svg?component';
    import LoginIcon from '@phosphor-icons/core/regular/sign-in.svg?component';
    import i18next from "i18next";
    import { createI18nStore } from "svelte-i18next";

    i18next.init({
        resources: {
            en: {
                translation: {
                    // Title text for various situations.
                    title: {
                        error: 'Uh-oh',
                        starting: 'Starting web server...',
                        deleting: 'Deleting site...',
                        deleted: 'Reinstall Drupal CMS',
                        installing: 'Installing...',
                        installed: 'Installation complete!',
                    },
                    // Status messages, shown below the title.
                    status: {
                        error: 'An error occurred while starting Drupal CMS. It has been automatically reported to the developers.',
                        installing: 'This might take a minute.',
                        running: 'Your site is running at<br /><code>{{url}}</code>',
                    },
                    // Progress messages, shown during initial set-up.
                    progress: {
                        init: 'Initializing...',
                        extracting: 'Extracting archive ({{percent}}% done)',
                    },
                    // Text (or titles) of buttons.
                    button: {
                        clearCache: 'Clear cache',
                        open: 'Open Drupal directory',
                        delete: 'Delete site',
                        login: 'Log in to site',
                        start: 'Start site',
                        visit: 'Visit site',
                    },
                    // Text used in dialog boxes (alerts, confirmations, etc).
                    dialog: {
                        cacheClearError: 'An error occurred while clearing the cache. It has been reported to the developers.',
                        confirmDelete: "Your site and content will be permanently deleted. You can't undo this. Are you sure?",
                    },
                },
            },
        },
        lng: navigator.language,
        fallbackLng: 'en',
    });
    const i18n = createI18nStore(i18next);

    let url: string | null = null;
    let title: string = '';
    let status: string = '';
    let detail: string = '';
    let progress: [number, number] | null = null;

    // Whether we're waiting for the main process to do a long operation.
    let isWorking: boolean = false;
    // Whether the user deleted the site (i.e., we should show the reinstall button).
    let wasDeleted: boolean = false;
    // There was an error.
    let isError: boolean = false;

    // Event handler when we receive progress information from the main process.
    function onProgress (event: any): void
    {
        const data = event.data;

        // Drupal is installed and we're going to start the web server.
        if (data.server) {
            title = $i18n.t('title.starting');
            status = detail = '';
            progress = null;
        }
        else {
            const { done, total } = data;
            progress = [done, total];

            // If the detail is the name of an archive, show a percentage of how much we've extracted.
            // Otherwise, the detail is a line of CLI output to display as-is.
            if (data.detail?.endsWith('.tar.gz')) {
                detail = $i18n.t('progress.extracting', { percent: Math.round((done / total) * 100) });
            }
            else {
                detail = data.detail || $i18n.t('progress.init');
            }
        }
    }
    window.addEventListener('message', (event): void => {
        if (event.source === window && event.data === 'port') {
            event.ports[0].onmessage = onProgress;
        }
    });

    function handleError (e: Error): void
    {
        url = null;
        title = $i18n.t('title.error');
        status = $i18n.t('status.error');
        detail = e.message;
        progress = null;
        isWorking = false;
        wasDeleted = false;
        isError = true;
    }

    async function startDrupal (): Promise<void>
    {
        url = null;
        title = $i18n.t('title.installing');
        status = $i18n.t('status.installing');
        detail = '';
        progress = null;
        isWorking = true;
        wasDeleted = false;
        isError = false;

        try {
            url = await drupal('start');
            if (url) {
                title = '';
                status = $i18n.t('status.running', { url });
            }
            else {
                title = $i18n.t('title.installed');
                status = '';
            }
            detail = '';
            isWorking = false;
        }
        catch (e: any) {
            handleError(e);
        }
    }

    async function deleteSite (): Promise<void>
    {
        if (confirm($i18n.t('dialog.confirmDelete'))) {
            url = null;
            title = $i18n.t('title.deleting');
            status = detail = '';
            progress = null;
            isWorking = true;
            wasDeleted = false;
            isError = false;

            try {
                await drupal('destroy');

                title = $i18n.t('title.deleted');
                wasDeleted = true;
                isWorking = false;
            }
            catch (e: any) {
                handleError(e);
            }
        }
    }

    async function clearCache (event: any): Promise<void>
    {
        const button = event.currentTarget;

        button.disabled = true;
        try {
            await drupal('clear-cache');
        }
        catch {
            alert($i18n.t('dialog.cacheClearError'));
        }
        finally {
            button.disabled = false;
        }
    }

    async function login (event: any): Promise<void>
    {
        const button = event.currentTarget;

        button.disabled = true;
        try {
            await drupal('login');
        }
        finally {
            button.disabled = false;
        }
    }

    onMount(startDrupal);

</script>

<div class="cms-installer">
  <header>
    <h1>
      <svg width="254" height="71" viewBox="0 0 823 201" fill="none" xmlns="http://www.w3.org/2000/svg">
        <title>Drupal CMS</title>
        <path d="M141.24 74.2003C141.129 73.9777 141.017 73.8664 140.795 73.6438C129.888 61.4012 114.418 44.0389 103.288 31.685C99.8377 28.0122 96.3875 24.3394 93.1599 20.5553C92.3808 19.665 91.7131 18.7746 90.934 17.8842C90.2662 17.2164 89.9323 16.7712 89.9323 16.7712H90.0436C86.2595 12.3194 83.2545 7.31103 81.1399 1.9688L80.5834 0.744534C80.5834 0.633238 80.4721 0.633238 80.3608 0.521941C80.2495 0.521941 80.0269 0.410645 79.9156 0.410645H79.8043C79.5817 0.410645 79.4704 0.521941 79.3591 0.521941C79.2478 0.633238 79.2478 0.633238 79.1365 0.744534L78.58 1.9688C76.3541 7.31103 73.3491 12.3194 69.6763 16.7712H69.7876C69.7876 16.7712 69.4537 17.2164 68.7859 17.8842C68.0069 18.7746 67.3391 19.665 66.56 20.5553C63.2211 24.3394 59.8822 28.0122 56.432 31.685C45.3024 44.0389 29.7208 61.4012 18.8138 73.6438C18.7025 73.8664 18.5912 73.9777 18.3686 74.2003C-22.8112 129.07 21.9301 173.811 21.9301 173.811H21.8188C35.0631 189.17 53.8722 198.63 74.0169 200.077C75.7976 200.299 77.6897 200.411 79.693 200.411H79.8043C81.6964 200.411 83.5884 200.299 85.4804 200.077C105.736 198.63 124.434 189.17 137.679 173.811H137.567C137.679 173.811 182.42 129.07 141.24 74.2003ZM45.3024 112.82L44.3007 114.378L44.1894 114.49C36.6212 123.616 32.1694 133.41 30.7225 143.093C30.4999 144.317 29.3869 145.096 28.274 144.874C27.4949 144.762 26.9384 144.206 26.6045 143.538C24.6012 138.864 23.2656 133.967 22.5979 128.958C20.1493 111.262 25.4916 95.7918 36.8438 82.5475C41.407 77.3166 45.9701 72.0857 50.5333 66.8547C51.3124 65.9643 52.6479 65.8531 53.5383 66.6321C53.6496 66.7434 53.6496 66.7434 53.7609 66.8547C57.4337 71.084 62.2194 76.5375 67.5617 82.7701C68.2295 83.5492 68.2295 84.7735 67.5617 85.6638C60.2161 94.4563 52.4253 103.805 45.4137 112.709L45.3024 112.82ZM108.63 158.674C104.401 169.804 96.0536 176.482 84.2562 178.374C67.4504 180.934 51.7576 169.47 49.1977 152.664C49.1977 152.442 49.1977 152.331 49.0864 152.108C47.7509 142.648 50.6446 134.3 56.7659 127.177C63.8889 118.83 79.5817 99.4646 79.8043 99.1307C80.1382 99.4646 96.8327 120.277 103.065 127.623C110.967 136.86 112.859 147.433 108.63 158.674ZM133.449 141.201C133.338 141.535 133.115 141.98 133.004 142.314C132.559 143.427 131.335 143.983 130.222 143.538C129.554 143.204 128.997 142.648 128.886 141.869C127.328 132.52 122.876 123.171 115.642 114.378L115.531 114.267L114.863 113.265L114.418 112.709C108.63 105.363 78.0236 69.5258 64.668 53.833C64.0002 53.0539 64.0002 51.8297 64.668 50.9393C69.1198 46.0423 73.5717 41.1452 77.9123 36.1369C78.6913 35.2465 80.0269 35.2465 80.9173 36.0256L81.0286 36.1369C83.0319 38.2515 84.924 40.3661 86.816 42.5921C98.9473 56.1702 111.19 69.5258 122.987 83.2153C137.901 100.466 141.351 120.277 133.449 141.201Z" fill="#009CDE"/>
        <path d="M540.907 63.7367H554.819V66.5191H549.254V80.3199H546.471V66.6304H540.907V63.7367Z" fill="#009CDE"/>
        <path d="M572.181 80.3199L570.957 68.2998L570.178 72.3065L567.284 80.3199H563.722L560.829 72.3065L560.05 68.2998L558.825 80.3199H555.932L557.601 63.7367H560.717L565.503 76.981L570.289 63.7367H573.405L575.075 80.3199H572.181Z" fill="#009CDE"/>
        <path d="M217.144 68.192H185.981V149.661H217.144C239.626 149.661 257.879 131.408 257.879 108.927C257.879 86.4447 239.626 68.192 217.144 68.192ZM236.399 128.181C231.279 133.301 224.379 136.194 217.144 136.083H199.559V81.6589H217.144C232.281 81.7702 244.412 94.1241 244.301 109.149C244.301 116.272 241.407 123.173 236.399 128.181ZM521.541 149.661H535.119V63.4063H521.541V149.661ZM280.806 94.2354V89.2271H267.228V149.772H280.806V112.377C280.806 105.81 286.259 102.805 291.379 102.805H299.838V89.1158H291.379C287.372 89.2271 283.477 91.1191 280.806 94.2354ZM353.26 120.501C353.371 125.176 351.924 129.628 349.142 133.412C346.36 136.862 342.13 138.754 337.678 138.643C334.006 138.754 330.444 137.419 327.662 134.97C324.768 132.188 323.321 128.07 323.321 122.727V90.34H309.743V125.844C309.632 132.633 312.414 139.199 317.423 143.874C322.542 148.659 329.331 151.219 336.232 151.108C342.464 151.219 348.586 148.993 353.149 144.653V149.772H366.727V90.34H353.149V120.501H353.26ZM410.244 88.7819C403.344 88.7819 396.666 91.2304 391.435 95.7936V90.2287H377.857V176.706H391.435V144.096C396.666 148.659 403.344 151.108 410.244 151.108C426.938 151.108 440.628 137.196 440.628 120.056C440.628 102.805 427.05 88.7819 410.244 88.7819ZM422.041 132.41C418.925 135.638 414.696 137.53 410.244 137.53C400.672 137.307 393.104 129.516 393.216 119.945C393.216 115.27 394.996 110.819 398.224 107.368C401.34 104.03 405.681 102.249 410.244 102.249C419.482 102.249 427.05 110.151 427.05 119.945C427.05 124.619 425.269 129.071 422.041 132.41ZM496.165 95.7936C490.934 91.2304 484.256 88.6706 477.356 88.7819C460.661 88.7819 446.972 102.694 446.972 119.834C446.972 136.973 460.55 150.997 477.356 150.997C484.256 151.108 491.045 148.548 496.165 143.985V149.661H509.743V90.1174H496.165V95.7936ZM477.356 137.641C468.007 137.641 460.439 129.739 460.439 119.945C460.439 110.262 468.007 102.36 477.356 102.36C486.705 102.36 494.273 110.262 494.273 119.945C494.273 129.628 486.593 137.641 477.356 137.641Z" fill="#009CDE"/>
        <path d="M656.356 138.293C652.644 142.237 648.275 145.33 643.248 147.573C638.221 149.815 632.808 150.937 627.008 150.937C621.363 150.937 616.027 149.854 611 147.689C606.051 145.523 601.72 142.546 598.008 138.757C594.296 134.89 591.357 130.443 589.192 125.417C587.104 120.313 586.06 114.861 586.06 109.061C586.06 103.261 587.104 97.8086 589.192 92.7046C591.357 87.6006 594.296 83.154 598.008 79.3646C601.72 75.5753 606.051 72.598 611 70.4326C616.027 68.19 621.363 67.0686 627.008 67.0686C632.808 67.0686 638.221 68.19 643.248 70.4326C648.275 72.6753 652.644 75.7686 656.356 79.7126L646.612 89.4566C644.137 86.75 641.199 84.662 637.796 83.1926C634.471 81.646 630.875 80.8726 627.008 80.8726C623.296 80.8726 619.777 81.6073 616.452 83.0766C613.127 84.546 610.227 86.5566 607.752 89.1086C605.355 91.6606 603.421 94.638 601.952 98.0406C600.56 101.443 599.864 105.117 599.864 109.061C599.864 112.927 600.56 116.601 601.952 120.081C603.421 123.483 605.355 126.461 607.752 129.013C610.227 131.565 613.127 133.575 616.452 135.045C619.777 136.514 623.296 137.249 627.008 137.249C630.875 137.249 634.471 136.475 637.796 134.929C641.199 133.382 644.137 131.255 646.612 128.549L656.356 138.293ZM742.51 149.661L736.478 90.5006L732.534 110.105L718.382 149.661H700.75L686.598 110.105L682.77 90.5006L676.738 149.661H662.818L671.054 68.3446H686.366L709.566 133.305L732.766 68.3446H748.078L756.314 149.661H742.51ZM793.98 102.449C797.228 103.454 800.36 104.653 803.376 106.045C806.392 107.359 809.06 109.022 811.38 111.033C813.7 112.966 815.517 115.286 816.832 117.993C818.147 120.622 818.804 123.793 818.804 127.505C818.804 127.659 818.804 127.853 818.804 128.085C818.727 131.797 817.876 135.083 816.252 137.945C814.705 140.806 812.617 143.203 809.988 145.137C807.359 147.07 804.343 148.539 800.94 149.545C797.537 150.55 794.057 151.053 790.5 151.053C786.865 151.053 782.805 150.589 778.32 149.661C773.835 148.733 768.731 147.07 763.008 144.673L768.228 132.029C772.559 133.73 776.58 135.045 780.292 135.973C784.081 136.823 787.523 137.249 790.616 137.249C792.24 137.249 793.903 137.094 795.604 136.785C797.305 136.475 798.852 135.934 800.244 135.161C801.636 134.387 802.757 133.382 803.608 132.145C804.536 130.907 805 129.399 805 127.621C805 125.687 804.497 124.063 803.492 122.749C802.487 121.434 801.211 120.351 799.664 119.501C798.117 118.573 796.455 117.799 794.676 117.181C792.897 116.562 791.312 116.059 789.92 115.673C786.672 114.59 783.54 113.391 780.524 112.077C777.585 110.762 774.956 109.138 772.636 107.205C770.316 105.271 768.46 102.951 767.068 100.245C765.753 97.4606 765.096 94.1353 765.096 90.2686C765.096 86.4793 765.908 83.154 767.532 80.2926C769.156 77.354 771.283 74.918 773.912 72.9846C776.619 71.0513 779.673 69.6206 783.076 68.6926C786.556 67.6873 790.113 67.1846 793.748 67.1846C797.228 67.1846 801.133 67.61 805.464 68.4606C809.872 69.234 814.821 70.7033 820.312 72.8686L815.324 85.6286C811.148 84.082 807.243 82.922 803.608 82.1486C799.973 81.298 796.609 80.8726 793.516 80.8726C791.892 80.8726 790.229 81.0273 788.528 81.3366C786.827 81.646 785.241 82.1873 783.772 82.9606C782.38 83.734 781.22 84.7393 780.292 85.9766C779.364 87.1366 778.9 88.6446 778.9 90.5006C778.9 92.434 779.403 94.058 780.408 95.3726C781.413 96.6873 782.689 97.8086 784.236 98.7366C785.783 99.5873 787.445 100.322 789.224 100.941C791.003 101.482 792.588 101.985 793.98 102.449Z" fill="#009CDE"/>
      </svg>
    </h1>
  </header>

  <main>
    <div class="cms-installer__main">
      <h2>{title}</h2>
      {#if isWorking}
        <div id="loader">
          <svg xmlns="http://www.w3.org/2000/svg" display="block" preserveAspectRatio="xMidYMid" width="48" height="48" style="shape-rendering: auto; display: block;" viewBox="0 0 100 100">
            <g fill="rgb(0, 156, 222)">
              <rect width="16" height="16" x="42" y="9" rx="8" ry="8">
                <animate attributeName="opacity" dur="0.8s" keyTimes="0;1" repeatCount="indefinite" values="1;0" begin="-0.7s"/>
              </rect>
              <rect width="16" height="16" x="42" y="9" rx="8" ry="8" transform="rotate(45 50 50)">
                <animate attributeName="opacity" dur="0.8s" keyTimes="0;1" repeatCount="indefinite" values="1;0" begin="-0.6s"/>
              </rect>
              <rect width="16" height="16" x="42" y="9" rx="8" ry="8" transform="rotate(90 50 50)">
                <animate attributeName="opacity" dur="0.8s" keyTimes="0;1" repeatCount="indefinite" values="1;0" begin="-0.5s"/>
              </rect>
              <rect width="16" height="16" x="42" y="9" rx="8" ry="8" transform="rotate(135 50 50)">
                <animate attributeName="opacity" dur="0.8s" keyTimes="0;1" repeatCount="indefinite" values="1;0" begin="-0.4s"/>
              </rect>
              <rect width="16" height="16" x="42" y="9" rx="8" ry="8" transform="rotate(180 50 50)">
                <animate attributeName="opacity" dur="0.8s" keyTimes="0;1" repeatCount="indefinite" values="1;0" begin="-0.3s"/>
              </rect>
              <rect width="16" height="16" x="42" y="9" rx="8" ry="8" transform="rotate(225 50 50)">
                <animate attributeName="opacity" dur="0.8s" keyTimes="0;1" repeatCount="indefinite" values="1;0" begin="-0.2s"/>
              </rect>
              <rect width="16" height="16" x="42" y="9" rx="8" ry="8" transform="rotate(270 50 50)">
                <animate attributeName="opacity" dur="0.8s" keyTimes="0;1" repeatCount="indefinite" values="1;0" begin="-0.1s"/>
              </rect>
              <rect width="16" height="16" x="42" y="9" rx="8" ry="8" transform="rotate(315 50 50)">
                <animate attributeName="opacity" dur="0.8s" keyTimes="0;1" repeatCount="indefinite" values="1;0" begin="0s"/>
              </rect>
            </g>
          </svg>
        </div>
      {/if}
      <p id="status">{@html status}</p>

      {#if url}
        <div>
          <button class="button" type="button" onclick={() => drupal('visit')}>
            {$i18n.t('button.visit')}&nbsp;
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="12" fill="none">
              <path fill="#fff" d="m13.03 6.53-4.5 4.5a.751.751 0 1 1-1.062-1.062l3.22-3.218H1.5a.75.75 0 0 1 0-1.5h9.188L7.469 2.03A.751.751 0 0 1 8.532.967l4.5 4.5a.75.75 0 0 1-.001 1.063Z"/>
            </svg>
          </button>
        </div>
      {/if}
      <div id="cli-output" class:error={isError}>{detail}</div>

      {#if progress}
        <div>
          <progress value={progress[0]} max={progress[1]}></progress>
        </div>
      {/if}
      <footer>
        {#if url}
          <button title={$i18n.t('button.clearCache')} class="spin-on-await" onclick={clearCache}>
            <CacheClearIcon width="32" />
          </button>
          <button title={$i18n.t('button.open')} onclick={() => drupal('open')}>
            <FolderIcon width="32" />
          </button>
          <button title={$i18n.t('button.login')} onclick={login}>
            <LoginIcon width="32" />
          </button>
          <button title={$i18n.t('button.delete')} onclick={deleteSite}>
            <TrashIcon width="32" />
          </button>
        {:else if wasDeleted}
          <button title={$i18n.t('button.start')} onclick={startDrupal}>
            <ReinstallIcon width="48" />
          </button>
        {/if}
      </footer>
    </div>
  </main>
</div>

<style>
  :global {
    html {
      display: table;
      width: 100%;
      height: 100%;
      margin: 0;
    }

    body {
      font-family: "Inter", system-ui;
      font-size: 100%;
      font-weight: normal;
      font-style: normal;
      line-height: 1.5;
      background-color: white;
      padding-block: 0;
      border-inline-start: 25px solid #CCEDF9;
      display: table-cell;

      @media (min-width: 48em) {
        border-inline-start-width: 35px;
      }
    }

    @keyframes spin {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(360deg);
      }
    }
  }

  .spin-on-await:disabled {
    animation: spin 600ms linear infinite;
  }

  .cms-installer {
    padding-block: 30px;
    padding-inline: 33px;
    min-block-size: 80%;

    @media (min-width: 78em) {
      padding-block: 60px;
      padding-inline: 66px;
    }

    @media (min-height: 500px) {
      display: grid;
      grid-template-areas: "stack";

      & > * {
        grid-area: stack;
      }
    }
  }

  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    align-self: start;

    @media (min-height: 500px) {
      margin-block-end: 2.5rem;
    }
  }

  h1 {
    margin-block: 0;
  }

  main {
    display: flex;
    place-items: center;
    text-align: center;
  }

  .cms-installer__main {
    inline-size: 100%;
    max-inline-size: 780px;
    min-block-size: 220px;
    position: relative;
    padding-top: 2rem;
  }

  #loader {
    display: inline-block;
    margin: 1rem auto;
  }

  .button {
    all: revert;
    display: inline-flex;
    align-items: center;
    flex-wrap: wrap;
    border: solid 1px transparent;
    font-family: inherit;
    line-height: 1;
    font-size: 1.125rem;
    color: white;
    background-color: rgb(5, 80, 230);
    padding: 1rem;
    border-radius: .5rem;
    font-weight: 600;
    box-shadow: none;
    cursor: pointer;

    &:hover {
      background-color: #0444c4;
    }

    &:focus {
      outline: 3px solid rgb(8, 113, 243);
      outline-offset: 2px;
    }
  }

  h2 {
    font-size: 1.875rem;
    font-weight: 600;
    margin-block-start: 0;
    line-height: 1.3;
  }

  p {
    color: #545560;
    margin-block-start: 0;
  }

  #cli-output {
    opacity: .4;

    &.error {
      opacity: 1;
      color: #b00;
    }
  }

  footer {
    margin-top: 2rem;
  }

  footer button {
    background-color: transparent;
    border: none;
    opacity: .3;
    transition: opacity .3s;

    &:hover {
      cursor: pointer;
      opacity: 1;
    }
  }
</style>
